// src/components/CreateBudgetModal.tsx
import React, { useEffect, useMemo, useState } from 'react';
import { Modal, View, Text, StyleSheet, Pressable, TextInput, Alert, Platform, ActivityIndicator, ScrollView } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { BudgetsService, CreateBudgetBody } from '../services/budgets';
import { CategoriesService } from '../services/categories';

type Mode = 'TYPE' | 'CATEGORY';

type Props = {
  visible: boolean;
  onClose: () => void;
  onCreated: () => Promise<void> | void; // refrescar la lista
};

type Category = {
  id: number;
  name: string;
  type: 'income' | 'expense';
};

export default function CreateBudgetModal({ visible, onClose, onCreated }: Props) {
  const [mode, setMode] = useState<Mode>('TYPE');
  const [loadingCats, setLoadingCats] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);

  const [amount, setAmount] = useState<string>('');
  const [type, setType] = useState<'INCOME' | 'EXPENSE' | undefined>('EXPENSE');
  const [categoryId, setCategoryId] = useState<number | undefined>(undefined);

  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [showStart, setShowStart] = useState(false);
  const [showEnd, setShowEnd] = useState(false);

  const [submitting, setSubmitting] = useState(false);

  // Cargar categorías solo si el modo es por categoría
  useEffect(() => {
    let mounted = true;
    if (mode === 'CATEGORY') {
      setLoadingCats(true);
      CategoriesService.getList()
        .then((data: any) => {
          if (!mounted) return;
          // Normaliza al tipo local
          const cats = (data ?? []).map((c: any) => ({
            id: c.id,
            name: c.name,
            type: (c.type === 'income' || c.type === 'INCOME') ? 'income' :
                  (c.type === 'expense' || c.type === 'EXPENSE') ? 'expense' : 'expense',
          }));
          setCategories(cats);
        })
        .catch((e) => {
          Alert.alert('Error', e?.message ?? 'No se pudieron cargar categorías');
        })
        .finally(() => setLoadingCats(false));
    }
    return () => {
      mounted = false;
    };
  }, [mode]);

  const canSubmit = useMemo(() => {
    const amt = Number(amount);
    if (!amt || isNaN(amt) || amt <= 0) return false;
    if (startDate > endDate) return false;
    if (mode === 'TYPE' && !type) return false;
    if (mode === 'CATEGORY' && !categoryId) return false;
    return true;
  }, [amount, startDate, endDate, mode, type, categoryId]);

  const handleSubmit = async () => {
    const amt = Number(amount);
    if (!canSubmit) {
      Alert.alert('Validación', 'Completa los campos correctamente.');
      return;
    }
    const body: CreateBudgetBody = {
      amount: amt,
      periodStart: toStartOfDayUTC(startDate),
      periodEnd: toEndOfDayUTC(endDate),
      ...(mode === 'TYPE' ? { type } : {}),
      ...(mode === 'CATEGORY' ? { categoryId } : {}),
    };

    // Regla de exclusividad (por si acaso)
    if (mode === 'TYPE') delete (body as any).categoryId;
    if (mode === 'CATEGORY') delete (body as any).type;

    try {
      setSubmitting(true);
      await BudgetsService.create(body);
      await onCreated();
      onClose();
      // reset básico
      setAmount('');
      setType('EXPENSE');
      setCategoryId(undefined);
    } catch (e: any) {
      Alert.alert('Error', e?.response?.data?.message ?? e?.message ?? 'No se pudo crear el presupuesto');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} transparent>
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
          <View style={styles.header}>
            <Text style={styles.title}>Nuevo presupuesto</Text>
            <Pressable onPress={onClose} style={styles.closeBtn}><Text style={styles.closeTxt}>✕</Text></Pressable>
          </View>

          <ScrollView contentContainerStyle={{ paddingBottom: 16 }}>
            {/* Modo */}
            <Text style={styles.label}>Modo</Text>
            <View style={styles.row}>
              <Pressable
                onPress={() => setMode('TYPE')}
                style={[styles.chip, mode === 'TYPE' && styles.chipActive]}
              >
                <Text style={[styles.chipTxt, mode === 'TYPE' && styles.chipTxtActive]}>Por tipo</Text>
              </Pressable>
              <Pressable
                onPress={() => setMode('CATEGORY')}
                style={[styles.chip, mode === 'CATEGORY' && styles.chipActive]}
              >
                <Text style={[styles.chipTxt, mode === 'CATEGORY' && styles.chipTxtActive]}>Por categoría</Text>
              </Pressable>
            </View>

            {/* Tipo (solo si modo TYPE) */}
            {mode === 'TYPE' && (
              <>
                <Text style={styles.label}>Tipo</Text>
                <View style={styles.row}>
                  <Pressable
                    onPress={() => setType('EXPENSE')}
                    style={[styles.chip, type === 'EXPENSE' && styles.chipActive]}
                  >
                    <Text style={[styles.chipTxt, type === 'EXPENSE' && styles.chipTxtActive]}>Gastos</Text>
                  </Pressable>
                  <Pressable
                    onPress={() => setType('INCOME')}
                    style={[styles.chip, type === 'INCOME' && styles.chipActive]}
                  >
                    <Text style={[styles.chipTxt, type === 'INCOME' && styles.chipTxtActive]}>Ingresos</Text>
                  </Pressable>
                </View>
              </>
            )}

            {/* Categoría (solo si modo CATEGORY) */}
            {mode === 'CATEGORY' && (
              <>
                <Text style={styles.label}>Categoría</Text>
                {loadingCats ? (
                  <View style={{ paddingVertical: 10 }}><ActivityIndicator /></View>
                ) : (
                  <View style={styles.selectBox}>
                    <ScrollView style={{ maxHeight: 160 }}>
                      {categories.map((c) => (
                        <Pressable
                          key={c.id}
                          onPress={() => setCategoryId(c.id)}
                          style={[styles.option, categoryId === c.id && styles.optionActive]}
                        >
                          <Text style={styles.optionName}>{c.name}</Text>
                          <Text style={styles.optionType}>{c.type === 'expense' ? 'Gasto' : 'Ingreso'}</Text>
                        </Pressable>
                      ))}
                    </ScrollView>
                  </View>
                )}
              </>
            )}

            {/* Monto */}
            <Text style={styles.label}>Monto asignado</Text>
            <TextInput
              value={amount}
              onChangeText={setAmount}
              placeholder="0.00"
              keyboardType="decimal-pad"
              style={styles.input}
            />

            {/* Periodo */}
            <Text style={styles.label}>Inicio del período</Text>
            <Pressable onPress={() => setShowStart(true)} style={styles.selector}>
              <Text>{toYMD(startDate)} (00:00 UTC)</Text>
            </Pressable>
            {showStart && (
              <DateTimePicker
                value={startDate}
                mode="date"
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                onChange={(_, d) => { setShowStart(false); if (d) setStartDate(d); }}
              />
            )}

            <Text style={[styles.label, { marginTop: 10 }]}>Fin del período</Text>
            <Pressable onPress={() => setShowEnd(true)} style={styles.selector}>
              <Text>{toYMD(endDate)} (23:59:59 UTC)</Text>
            </Pressable>
            {showEnd && (
              <DateTimePicker
                value={endDate}
                mode="date"
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                onChange={(_, d) => { setShowEnd(false); if (d) setEndDate(d); }}
              />
            )}

            <Pressable
              onPress={handleSubmit}
              disabled={!canSubmit || submitting}
              style={[styles.saveBtn, (!canSubmit || submitting) && { opacity: 0.6 }]}
            >
              <Text style={styles.saveTxt}>{submitting ? 'Creando…' : 'Crear presupuesto'}</Text>
            </Pressable>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// Helpers
function toYMD(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function toStartOfDayUTC(d: Date) {
  const iso = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0)).toISOString();
  return iso;
}
function toEndOfDayUTC(d: Date) {
  const iso = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 0)).toISOString();
  return iso;
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)', justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: '#fff', borderTopLeftRadius: 16, borderTopRightRadius: 16,
    paddingHorizontal: 16, paddingTop: 10, maxHeight: '90%',
  },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  title: { fontSize: 18, fontWeight: '700' },
  closeBtn: { paddingHorizontal: 10, paddingVertical: 6 },
  closeTxt: { fontSize: 18 },
  label: { fontSize: 14, color: '#555', marginTop: 10, marginBottom: 6 },
  row: { flexDirection: 'row', gap: 10 },
  chip: { borderWidth: 1, borderColor: '#ddd', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8 },
  chipActive: { backgroundColor: '#111827', borderColor: '#111827' },
  chipTxt: { color: '#111827' },
  chipTxtActive: { color: '#fff', fontWeight: '700' },
  selectBox: { borderWidth: 1, borderColor: '#ddd', borderRadius: 12, padding: 6 },
  option: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 10, paddingHorizontal: 8, borderRadius: 10 },
  optionActive: { backgroundColor: '#f3f4f6' },
  optionName: { fontWeight: '600', color: '#111827' },
  optionType: { color: '#6b7280' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 16 },
  selector: { borderWidth: 1, borderColor: '#ddd', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 12 },
  saveBtn: { marginTop: 16, marginBottom: 24, backgroundColor: '#111827', paddingVertical: 14, borderRadius: 14, alignItems: 'center' },
  saveTxt: { color: 'white', fontSize: 16, fontWeight: '700' },
});
