// src/components/BudgetCard.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { BudgetDTO, BudgetProgressDTO } from '../services/budgets';
import { useMoney } from '../utils/money';

interface Props {
  budget: BudgetDTO;
  progress?: BudgetProgressDTO | null;
  categoryName?: string; // opcional: mapea id → nombre si tienes contexto de categorías
}

export default function BudgetCard({ budget, progress, categoryName }: Props) {
  const money = useMoney();

  const title = (() => {
    if (progress?.scope === 'CATEGORY' || budget.categoryId) {
      return categoryName ?? `Categoría #${budget.categoryId ?? '—'}`;
    }
    if (progress?.scope === 'TYPE' || budget.type) {
      return budget.type === 'EXPENSE' ? 'Gastos' : 'Ingresos';
    }
    return 'Presupuesto';
  })();

  // 👇 Paréntesis para mezclar ?? con ||
  const allocated = (progress?.allocated ?? Number(budget.amount)) || 0;
  const spent = progress?.spent ?? undefined;
  const remaining = progress?.remaining ?? (allocated - (spent ?? 0));
  const percent =
    progress?.percent ??
    (allocated > 0 && spent != null ? Math.round((spent / allocated) * 100) : 0);

  const periodStart = progress?.period.start ?? budget.periodStart;
  const periodEnd = progress?.period.end ?? budget.periodEnd;

  const over = spent != null ? spent > allocated : false;
  const pctWidth = Math.max(0, Math.min(percent, 200)); // cap visual en 200%

  return (
    <View style={[styles.card, over && styles.over]}>
      <View style={styles.rowBetween}>
        <Text style={styles.title}>{title}</Text>
        <Text style={[styles.badge, over ? styles.badgeOver : styles.badgeOk]}>
          {over ? 'Sobrepasado' : 'En curso'}
        </Text>
      </View>

      <Text style={styles.subtitle}>
        {fmtDate(periodStart)} – {fmtDate(periodEnd)}
      </Text>

      <View style={styles.rowBetween}>
        <Text style={styles.amount}>Asignado: {money.format(allocated)}</Text>
        {spent != null && <Text style={styles.amount}>Gastado: {money.format(spent)}</Text>}
      </View>

      <View style={styles.progressWrap}>
        <View style={styles.progressBg}>
          <View
            style={[styles.progressFill, { width: `${pctWidth}%` }, over && styles.progressOver]}
          />
        </View>
        <Text style={styles.percentLabel}>{percent}%</Text>
      </View>

      <Text style={[styles.remaining, over && styles.remainingOver]}>
        Restante: {money.format(Math.max(0, remaining))}
      </Text>

      <Text style={styles.meta}>ID: {budget.id} · {budget.type ?? 'GENERAL'}</Text>
    </View>
  );
}

function fmtDate(iso: string) {
  const d = new Date(iso);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: '#eee',
    marginBottom: 12,
  },
  over: { borderColor: '#fca5a5', backgroundColor: '#fffafa' },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  title: { fontSize: 16, fontWeight: '700', color: '#111827' },
  subtitle: { marginTop: 2, color: '#6b7280' },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, fontSize: 12, overflow: 'hidden' },
  badgeOk: { backgroundColor: '#e0f2fe', color: '#0369a1' },
  badgeOver: { backgroundColor: '#fee2e2', color: '#991b1b' },
  amount: { marginTop: 8, fontWeight: '600', color: '#374151' },
  progressWrap: { marginTop: 10 },
  progressBg: { height: 10, backgroundColor: '#f3f4f6', borderRadius: 999, overflow: 'hidden' },
  progressFill: { height: 10, backgroundColor: '#111827' },
  progressOver: { backgroundColor: '#b91c1c' },
  percentLabel: { marginTop: 6, color: '#6b7280', fontSize: 12 },
  remaining: { marginTop: 4, fontWeight: '700', color: '#065f46' },
  remainingOver: { color: '#991b1b' },
  meta: { marginTop: 8, fontSize: 12, color: '#9ca3af' },
});
