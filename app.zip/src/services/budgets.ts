// src/services/budgets.ts
import { api } from '../api/client';

export type BudgetType = 'INCOME' | 'EXPENSE' | null;

export interface BudgetDTO {
  id: number;
  userId: number;
  type: BudgetType;        // EXPENSE, INCOME o null
  categoryId: number | null;
  amount: string;          // viene como string desde el backend
  periodStart: string;     // ISO
  periodEnd: string;       // ISO
  createdAt: string;       // ISO
  updatedAt: string;       // ISO
}

export type BudgetScope = 'CATEGORY' | 'ACCOUNT' | 'GLOBAL' | 'TYPE';

export interface BudgetProgressDTO {
  budgetId: number;
  scope: BudgetScope;      // p.ej. 'CATEGORY'
  type: BudgetType;        // EXPENSE / INCOME / null
  categoryId: number | null;
  allocated: number;       // monto asignado
  spent: number;           // gastado
  remaining: number;       // restante (>=0)
  percent: number;         // ej. 120
  period: { start: string; end: string };
}

export interface CreateBudgetBody {
  type?: Exclude<BudgetType, null>; // 'INCOME' | 'EXPENSE'
  amount: number;
  categoryId?: number;
  periodStart: string; // ISO
  periodEnd: string;   // ISO
}

export const BudgetsService = {
  async getList(): Promise<BudgetDTO[]> {
    const { data } = await api.get<BudgetDTO[]>('/budgets');
    return data;
  },

  async getProgress(id: number): Promise<BudgetProgressDTO> {
    const { data } = await api.get<BudgetProgressDTO>(`/budgets/${id}/progress`);
    return data;
  },

  async create(body: CreateBudgetBody): Promise<BudgetDTO> {
    const { data } = await api.post<BudgetDTO>('/budgets', body);
    return data;
  },
};
