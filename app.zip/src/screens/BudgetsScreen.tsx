// src/screens/BudgetsScreen.tsx
import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, ActivityIndicator, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { BudgetsService, BudgetDTO, BudgetProgressDTO } from '../services/budgets';
import BudgetCard from '../components/BudgetCard';
import CreateBudgetModal from '../components/CreateBudgetModal';

// Tipo combinado para la UI
type BudgetRow = { budget: BudgetDTO; progress: BudgetProgressDTO | null };

export default function BudgetsScreen() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [rows, setRows] = useState<BudgetRow[]>([]);
  const [showCreate, setShowCreate] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const budgets = await BudgetsService.getList();

      // Cargar progresos en paralelo
      const progresses = await Promise.all(
        budgets.map(async (b) => {
          try {
            return await BudgetsService.getProgress(b.id);
          } catch {
            return null; // tolera fallos puntuales
          }
        })
      );

      const merged: BudgetRow[] = budgets.map((b, i) => ({ budget: b, progress: progresses[i] }));

      // Orden opcional: por createdAt desc
      merged.sort(
        (a, b) =>
          new Date(b.budget.createdAt).getTime() - new Date(a.budget.createdAt).getTime()
      );

      setRows(merged);
    } catch (e) {
      console.error(e);
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await load();
    } finally {
      setRefreshing(false);
    }
  }, [load]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <SafeAreaView style={styles.centered}>
        <ActivityIndicator size="large" />
        <Text style={{ marginTop: 8 }}>Cargando presupuestos…</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        contentContainerStyle={{ padding: 16, paddingBottom: 120 }}
        data={rows}
        keyExtractor={(row) => String(row.budget.id)}
        renderItem={({ item }) => (
          <BudgetCard budget={item.budget} progress={item.progress} />
        )}
        ListEmptyComponent={() => (
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>Sin presupuestos</Text>
            <Text style={styles.emptyText}>
              Crea tu primer presupuesto para comenzar a controlar tus gastos.
            </Text>
          </View>
        )}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      />

      {/* Botón flotante agregar */}
      <Pressable style={styles.fab} onPress={() => setShowCreate(true)}>
        <Text style={styles.fabTxt}>＋</Text>
      </Pressable>

      {/* Modal crear */}
      <CreateBudgetModal
        visible={showCreate}
        onClose={() => setShowCreate(false)}
        onCreated={async () => {
          await load();
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { paddingVertical: 60, alignItems: 'center' },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: '#111827' },
  emptyText: { marginTop: 6, color: '#6b7280', textAlign: 'center', paddingHorizontal: 16 },
  fab: {
    position: 'absolute', right: 20, bottom: 30,
    backgroundColor: '#111827', width: 56, height: 56, borderRadius: 28,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4, elevation: 4,
  },
  fabTxt: { color: '#fff', fontSize: 28, lineHeight: 28, marginTop: -2 },
});
